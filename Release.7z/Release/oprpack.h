#ifndef __DEFINED__OPRTR__PACK__
#define __DEFINED__OPRTR__PACK__
#include <super/oppack.h> /* alt. */
#endif
