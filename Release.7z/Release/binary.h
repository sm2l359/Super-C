#ifndef XSC_BINARY_FUNCTIONS

/* fallback header */

#include <super/binfactory.h>
#endif
