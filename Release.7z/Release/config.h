/** ///PRE-DEFINED SETTINGS. **/
#if !defined(CONF_DEFINED) || defined(CONF_DEFINED)

    #ifndef XSCCONF_ANSI_ESCAPE /* //1 = Automatic Activation of ANSI-ESC | 0 = Disabled or Manual Activation. // */
    #define XSCCONF_ANSI_ESCAPE ENABLED /* //alt: OPT_ENABLED  */
    #endif

    #ifndef XSCCONF_USE_ANSI_ONLY
        #define XSCCONF_USE_ANSI_ONLY DISABLED
    #else
        #if XSCCONF_USE_ANSI_ONLY >= XSCMODE_ENABLED
            #undef XSCCONF_ANSI_ESCAPE
            #define XSCCONF_ANSI_ESCAPE XSCMODE_DISABLED
        #endif
    #endif
    #ifndef XSCCONF_STDCON_NOCLEANUP /* //Windows Exclusive Option Only. // 'stdcon.h' // */
    #define XSCCONF_STDCON_NOCLEANUP DISABLED
    #endif

    #ifndef XSCCONF_INCLUDE_ALL /* // 'stdbasic.h' //  */
    #define XSCCONF_INCLUDE_ALL DISABLED
    #endif

    #ifndef XSCCONF_NORETURN /* //converts some types like char* and int to void type, and disables returning of the functions containing them. // */
    #define XSCCONF_NORETURN DISABLED
    #endif

    #ifndef XSCCONF_STDCON_NORETURN_CPOS /* // 'stdcon.h' //  */
    #define XSCCONF_STDCON_NORETURN_CPOS DISABLED
    #endif

    #ifndef XSCCONF_DRAWS_BOUNDS /* // 'draws.h' // */
    #define XSCCONF_DRAWS_BOUNDS ENABLED
    #endif

    #ifndef XSCCONF_ADVANCED_DRAWS /* // 'draws.h' // */
    #define XSCCONF_ADVANCED_DRAWS DISABLED
    #endif

    #ifndef XSCCONF_EXCLUSIVE_HDR
    #define XSCCONF_EXCLUSIVE_HDR ENABLED /* Stands For: "Exclusive Header Type" */
        /*
        ///Ex: stdcon clear(void); | draws draw_TextBox(void); (XSCCONF_EXCLUSIVE_HDR=on)
        ///Ex: void clear(void);   | void draw_TextBox(void); (XSCCONF_EXCLUSIVE_HDR=off)
        */
    #endif

    #if defined(XSCCONF_STDCON_AUTO_UPDATE)
        #if XSCCONF_STDCON_AUTO_UPDATE >= XSCMODE_ENABLED
            #ifndef XSCCONF_STDCON_AUTO_UPDATE_CSBI
            #define XSCCONF_STDCON_AUTO_UPDATE_CSBI ENABLED
            #endif

            #ifndef XSCCONF_STDCON_AUTO_UPDATE_COLOR
            #define XSCCONF_STDCON_AUTO_UPDATE_COLOR ENABLED
            #endif
        #elif XSCCONF_STDCON_AUTO_UPDATE <= XSCMODE_DISABLED
            #ifndef XSCCONF_STDCON_AUTO_UPDATE_CSBI
            #define XSCCONF_STDCON_AUTO_UPDATE_CSBI DISABLED
            #endif

            #ifndef XSCCONF_STDCON_AUTO_UPDATE_COLOR
            #define XSCCONF_STDCON_AUTO_UPDATE_COLOR DISABLED
            #endif
        #endif
    #else
        #ifndef XSCCONF_STDCON_AUTO_UPDATE_CSBI
        #define XSCCONF_STDCON_AUTO_UPDATE_CSBI ENABLED
        #endif

        #ifndef XSCCONF_STDCON_AUTO_UPDATE_COLOR
        #define XSCCONF_STDCON_AUTO_UPDATE_COLOR ENABLED
        #endif
    #endif

    #ifndef XSCCONF_STDCON_AUTO_UPDATE
        #if XSCCONF_STDCON_AUTO_UPDATE_COLOR != XSCCONF_STDCON_AUTO_UPDATE_CSBI
            #define XSCCONF_STDCON_AUTO_UPDATE ENABLED
        #else
            #define XSCCONF_STDCON_AUTO_UPDATE ENABLED
        #endif
    #endif

    #ifndef XSCCONF_SUPRESS_WARNINGS
    #define XSCCONF_SUPRESS_WARNINGS DISABLED
    #endif

    /* [C] change to something like 'XSCCONF_SHARED' in the future. */
    #ifndef XSCCONF_THREADING /* mandatory to be set 'true' if working with multiple threads, some optimization will be undone. */
    #define XSCCONF_THREADING DISABLED /* if this is not set 'true', then it may result in severe issues with threading. */
    #endif

    /* [C] change to 'USE_REC_MODEL' */
    #ifndef XSCCONF_TYPEOF_MOD3
    #define XSCCONF_TYPEOF_MOD3 DISABLED
    #endif

    #ifndef XSCCONF_STRINGS_STRCUT_MODIFY_ALL
    #define XSCCONF_STRINGS_STRCUT_MODIFY_ALL ENABLED
    #endif

    #ifndef XSCCONF_STDCON_UPDATE_COORDS
    #define XSCCONF_STDCON_UPDATE_COORDS ENABLED
    #endif

    #ifndef XSCCONF_SUPER_C_SPLASH_SCREEN
    #define XSCCONF_SUPER_C_SPLASH_SCREEN ENABLED
    #endif

    #ifndef XSSCCONF_ALT_SPELLINGS
    #define XSCCONF_ALTSPELLING ENABLED
    #endif

    #define CONF_DEFINED 1

#endif
