#ifndef _3XSC_3DAPI
#define _3XSC_3DAPI

#ifndef __STDCON__
#error Please, include 'stdcon.h', in order to use 'three.h'
#endif

#endif /* _3XSC_3DAPI */
