#ifndef __XCM_CUSTOM_SERVERS
#define __XCM_CUSTOM_SERVERS

#endif /* __XSC_CUSTOM_SERVERS */
