#ifndef __DEFINED__OPRTR__PACK__
#define __DEFINED__OPRTR__PACK__
#include <super/oprpack.h> /* fallback. */
#endif
