#ifndef __DEBUGGER__
#define __DEBUGGER__

/* fallback header */

#include <super/debug>
#endif
