#ifndef __EMPTY_FILE_TEMPLATE
#define __EMPTY_FILE_TEMPLATE

/* write the code down here. */

#endif /* __EMPTY_TEMPLATE */
